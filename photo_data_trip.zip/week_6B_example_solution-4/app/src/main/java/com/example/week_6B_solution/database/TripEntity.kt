package com.example.week_6B_solution.database

import android.content.Context
import android.net.Uri
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.week_6B_solution.model.Image
import com.example.week_6B_solution.utils.getOrMakeThumbNail

@Entity(tableName = "trip", indices=[Index(value=["id", "trip_title"])])
data class TripEntity (
    @PrimaryKey(autoGenerate = true) var id: Int = 0,
    @ColumnInfo(name="trip_path") val tripPath: String,
    @ColumnInfo(name="trip_title") var title1: String,
    @ColumnInfo(name="trip_start") var end: String,
    @ColumnInfo(name="trip_start") var start: String,
    @ColumnInfo(name="trip_description") var description1: String?,
    @ColumnInfo(name="trip_date") var date: String,
    @ColumnInfo(name="thumbnail_filename") var thumbnail1: String?)
